history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
vi /etc/hostname
vi /etc/hosts
reboot
cat /etc/debian_version
cp /etc/apt/sources.list /etc/apt/sources.list.bak
vi /etc/aptsources.list
apt update
vi /etc/apt/sources.list
apt update
ping -c 4 8.8.8.8
apt update
apt upgrade -y
 
apt upgrade -y
apt upgrade
ip a
ping -c 4 8.8.8.8
vi /etc/network/interfaces
systemctl restart networking
ping -c 4 8.8.8.8
apt upgrade
apt update
apt upgrade --fix-missing -y
reboot
