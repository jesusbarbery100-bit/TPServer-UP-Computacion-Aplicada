#!/bin/bash

# Punto 5: opcion de ayuda

if ["$1" == "-help"]; then
	echo "uso del script: $0 <origen> <destino>"
	echo "ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

# Punto 4: comprobacion de recepcion de argumentos (origen y destino)

if [ $# -ne 2 ]; then
	echo "Error: deben ingresar exactamente la carpeta de origen y la de destino"
	echo "Usa '$0 -help' para obtener ayuda sobre la sintaxis."
	exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Punto 6: validacion de disponibilidad de sistemas de archivos

# 1. comprueba que la carpeta de origen exista en el sistema 
if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio de origen ´$ORIGEN' no existe."
	exit 1
fi

# 2. comprueba que el directorio de destino exista y que la particion este montada
if [ ! -d "$DESTINO" ] || ! mountpoint -q "$DESTINO"; then
	echo "Error: El diectorio de destino '$DESTINO' no existe o la particion no esta montada."
	exit 1
fi

# Punto 3: comprension y guardado en /backup_dir con fecha ANSI (YYYYMMDD)

FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
ARCHIVO_FINAL="$DESTINO/${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "Iniciando proceso de respaldo..."
tar -czf "$ARCHIVO_FINAL" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

#validacion de resultado del comando tar
if [ $? -eq 0 ]; then
	echo "Respaldo generado con exito en: $ARCHIVO_FINAL"
else 
	echo "Ocurrio un error al generar la copia de seguridad" 
	exit 1
fi 
